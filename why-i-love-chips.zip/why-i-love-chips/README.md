# why i love chips

A Pen created on CodePen.

Original URL: [https://codepen.io/khawal-abdullah/pen/gbrXRWy](https://codepen.io/khawal-abdullah/pen/gbrXRWy).

